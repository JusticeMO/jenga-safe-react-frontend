
import { PaymentMethodsView } from "./payment/PaymentMethodsView";

export { PaymentMethodsView };
